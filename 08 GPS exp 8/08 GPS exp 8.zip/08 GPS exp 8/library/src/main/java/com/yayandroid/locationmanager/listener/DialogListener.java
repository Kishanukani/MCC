package com.yayandroid.locationmanager.listener;

public interface DialogListener {

    void onPositiveButtonClick();

    void onNegativeButtonClick();

}
